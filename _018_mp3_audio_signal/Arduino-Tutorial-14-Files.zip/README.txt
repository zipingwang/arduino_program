===OPEN SOURCE LICENSE===
These files are distributed under the GNU GPL Open Source License.
Further information can be found in the LICENSE.txt file.

===FILE INFORMATION===
These files are meant to accompany Jeremy Blum's Arduino Tutorial Series.
These tutorials were sponsored by element14 (http://www.element14.com).
You can watch the tutorials in these places:
>>element14 Arduino Videos	- http://www.element-14.com/community/groups/arduino?view=video
>>YouTube			- http://www.youtube.com/view_play_list?p=A567CE235D39FA84
>>Jeremy's Website		- http://jeremyblum.com/category/arduino-tutorials/

===ARDUINO HELP===
If you need help with the Arduino please use these resources:
>>element14 Arduino Group	- http://www.element-14.com/community/groups/arduino
>>Arduino Forums		- http://arduino.cc/forum/
>>Jeremy's Contact Page		- http://jeremyblum.com/contact/

===AUTHOR INFO===
The Original author of these files is Jeremy Blum.
He can be reached through his website, http://www.jeremyblum.com.
NO WARRANTY is provided with these files, since they are released under the GNU GPL.
Follow Jeremy on Twitter: http://www.twitter.com/sciguy14
Subscribe to Jeremy on Youtube: http://www.youtube.com/subscription_center?add_user=sciguy14
"Like" Jeremy on Facebook: http://www.facebook.com/JeremyTheEngineer